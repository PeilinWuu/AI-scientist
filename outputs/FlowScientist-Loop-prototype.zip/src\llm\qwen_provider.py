"""Qwen/DashScope provider using an OpenAI-compatible chat endpoint."""

from __future__ import annotations

import requests

from src.config import settings
from src.llm.base import LLMProvider


class QwenProvider(LLMProvider):
    """Thin Qwen provider. Secrets are read only from environment variables."""

    def __init__(self) -> None:
        if not settings.dashscope_api_key:
            raise ValueError("DASHSCOPE_API_KEY is required when LLM_PROVIDER=qwen.")
        self.api_key = settings.dashscope_api_key
        self.model = settings.llm_model
        self.base_url = settings.llm_base_url.rstrip("/")

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]
