"""Critic agent that turns analysis into next-step guidance."""

from __future__ import annotations

from src.schemas import Constraints


class CriticAgent:
    """Applies simple scientific feedback rules for the next iteration."""

    def critique(self, analysis: dict, constraints: Constraints, previous_best: dict | None) -> dict:
        """Decide which direction the next planner should move."""

        best = analysis["best_candidate"]
        energy_too_high = best["energy_cost"] > constraints.max_energy_cost * 0.95
        stability_too_low = best["stability_score"] < constraints.min_stability + 0.05
        speed_too_low = best["mean_speed"] < 0.75

        improvement = analysis.get("improvement_vs_previous_best")
        efficiency_improved = True
        if previous_best and improvement is not None:
            if constraints.target_metric == "energy_cost":
                efficiency_improved = improvement > 0
            else:
                efficiency_improved = improvement >= 0

        if energy_too_high:
            next_strategy = "reduce frequency or amplitude to lower energy cost"
        elif stability_too_low:
            next_strategy = "lower amplitude or increase stiffness to improve stability"
        elif speed_too_low:
            next_strategy = "increase frequency or amplitude to recover propulsion speed"
        elif efficiency_improved:
            next_strategy = "continue local search around the best measured candidate"
        else:
            next_strategy = "broaden local search because the last move did not improve the target"

        return {
            "energy_too_high": bool(energy_too_high),
            "stability_too_low": bool(stability_too_low),
            "speed_too_low": bool(speed_too_low),
            "efficiency_improved": bool(efficiency_improved),
            "next_strategy": next_strategy,
            "message": (
                f"Next planner should {next_strategy}. "
                "This links measured results directly to the next experiment plan."
            ),
        }
