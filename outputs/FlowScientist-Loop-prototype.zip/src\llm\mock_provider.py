"""Deterministic mock LLM provider for offline demos."""

from __future__ import annotations

from .base import LLMProvider


class MockLLMProvider(LLMProvider):
    """Returns compact, deterministic text so the project runs without API keys."""

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        return (
            "MockLLM: use constraint-aware local search, compare each iteration "
            "against previous results, and update the next plan from measured failures."
        )
