"""Streamlit UI for FlowScientist-Loop."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from src.schemas import Constraints, RunRequest
from src.utils.plotting import plot_efficiency_history
from src.workflow.experiment_loop import get_run, run_experiment_loop


st.set_page_config(page_title="FlowScientist-Loop", layout="wide")

st.title("FlowScientist-Loop")
st.caption("Scientific experiment task planning and feedback iteration prototype")

with st.sidebar:
    st.header("Experiment setup")
    max_iterations = st.number_input("Max iterations", min_value=1, max_value=10, value=3)
    min_stability = st.slider("min_stability", 0.0, 1.0, 0.65, 0.01)
    max_energy_cost = st.number_input("max_energy_cost", min_value=0.1, value=2.2, step=0.1)
    target_metric = st.selectbox(
        "target_metric",
        ["efficiency", "mean_speed", "energy_cost", "stability_score"],
        index=0,
    )
    random_seed = st.number_input("random_seed", value=42, step=1)

research_goal = st.text_area(
    "research_goal",
    value="Improve soft swimmer propulsion efficiency while limiting energy cost and unstable oscillation.",
    height=100,
)
human_feedback = st.text_input("optional human_feedback", value="")

if "run_id" not in st.session_state:
    st.session_state.run_id = None

if st.button("Run feedback loop", type="primary"):
    constraints = Constraints(
        min_stability=min_stability,
        max_energy_cost=max_energy_cost,
        target_metric=target_metric,
    )
    request = RunRequest(
        research_goal=research_goal,
        constraints=constraints,
        max_iterations=int(max_iterations),
        human_feedback=human_feedback or None,
        random_seed=int(random_seed),
    )
    with st.spinner("Running multi-agent virtual experiment loop..."):
        summary = run_experiment_loop(request)
    st.session_state.run_id = summary.run_id
    st.success(f"Run completed: {summary.run_id}")

if st.session_state.run_id:
    run = get_run(st.session_state.run_id)
    st.subheader("Run summary")
    st.write(f"Run ID: `{run['run_id']}`")
    st.write(f"Artifacts: `{run['run_dir']}`")

    result_frames: list[pd.DataFrame] = []
    for item in run["history"]:
        st.divider()
        st.subheader(f"Iteration {item['iteration']}")
        st.markdown(f"**Plan strategy:** {item['plan']['strategy']}")
        plan_rows = [
            {"candidate_id": c["candidate_id"], **c["params"], "rationale": c["rationale"]}
            for c in item["plan"]["candidates"]
        ]
        st.dataframe(pd.DataFrame(plan_rows), use_container_width=True)

        df = pd.DataFrame(item["results"])
        result_frames.append(df)
        st.markdown("**Experiment results**")
        st.dataframe(df, use_container_width=True)

        st.markdown("**AI analysis**")
        st.info(item["analysis"]["summary"])
        st.markdown("**Feedback for next iteration**")
        st.warning(item["feedback"]["message"])

    if result_frames:
        st.subheader("Efficiency change")
        st.pyplot(plot_efficiency_history(result_frames))

    st.subheader("Final report")
    report_md = run["final_report"] or ""
    st.markdown(report_md)

    report_json_path = Path(run["run_dir"]) / "final_report.json"
    report_json_text = report_json_path.read_text(encoding="utf-8")
    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "Download final_report.md",
            data=report_md,
            file_name="final_report.md",
            mime="text/markdown",
        )
    with col2:
        st.download_button(
            "Download final_report.json",
            data=report_json_text,
            file_name="final_report.json",
            mime="application/json",
        )
