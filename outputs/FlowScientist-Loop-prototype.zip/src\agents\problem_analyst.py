"""Problem analysis agent."""

from __future__ import annotations

from src.llm.base import LLMProvider
from src.schemas import Constraints


class ProblemAnalystAgent:
    """Extracts variables, constraints, and optimization priorities."""

    def __init__(self, llm: LLMProvider) -> None:
        self.llm = llm

    def analyze(
        self, research_goal: str, constraints: Constraints, human_feedback: str | None
    ) -> dict:
        """Return a structured problem understanding for downstream agents."""

        text = f"{research_goal} {human_feedback or ''}".lower()
        priorities = []
        if "energy" in text or "能耗" in text:
            priorities.append("energy_cost")
        if "stability" in text or "稳定" in text:
            priorities.append("stability_score")
        if "speed" in text or "速度" in text or "推进" in text:
            priorities.append("mean_speed")
        if "efficiency" in text or "效率" in text:
            priorities.append("efficiency")
        if constraints.target_metric not in priorities:
            priorities.insert(0, constraints.target_metric)

        llm_note = self.llm.generate(
            "You are a scientific experiment planning assistant.",
            f"Summarize the goal and constraints: {research_goal}",
        )

        return {
            "research_goal": research_goal,
            "variables": [
                "amplitude",
                "frequency",
                "wavelength",
                "stiffness",
                "phase",
            ],
            "constraints": constraints.model_dump(),
            "priorities": priorities,
            "human_feedback": human_feedback,
            "llm_note": llm_note,
        }
