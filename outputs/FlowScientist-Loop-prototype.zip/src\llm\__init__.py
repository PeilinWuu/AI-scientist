"""LLM provider factory."""

from __future__ import annotations

from src.config import settings
from src.llm.base import LLMProvider
from src.llm.mock_provider import MockLLMProvider
from src.llm.qwen_provider import QwenProvider


def get_llm_provider() -> LLMProvider:
    """Create the configured LLM provider, defaulting to Mock."""

    if settings.llm_provider == "qwen":
        return QwenProvider()
    return MockLLMProvider()
