# FlowScientist-Loop

FlowScientist-Loop is a minimum runnable prototype for scientific experiment task planning and feedback iteration. It targets soft robotic swimmer and flow-field optimization scenarios.

The key point is not one-shot hypothesis generation. The system runs a closed loop:

1. Understand the research goal.
2. Plan virtual experiment tasks.
3. Execute a lightweight soft-swimmer simulator.
4. Analyze measured results.
5. Critique failures and trends.
6. Plan the next round from feedback.
7. Generate a final Markdown and JSON report.

## Tech Stack

- Backend: FastAPI
- Frontend: Streamlit
- Data: pandas, numpy
- Charts: matplotlib
- LLM provider abstraction:
  - `MockLLMProvider` by default, works without API keys.
  - `QwenProvider` is reserved for DashScope/Qwen API use.

## Project Structure

```text
FlowScientist-Loop/
  README.md
  requirements.txt
  .env.example
  app_streamlit.py
  run_examples.py
  src/
    main_api.py
    config.py
    schemas.py
    llm/
      base.py
      mock_provider.py
      qwen_provider.py
    agents/
      problem_analyst.py
      experiment_planner.py
      data_analyst.py
      critic.py
      report_writer.py
    simulator/
      soft_swimmer_simulator.py
    workflow/
      experiment_loop.py
    utils/
      io.py
      plotting.py
  examples/
    case_efficiency_first.json
    case_low_energy.json
    case_human_feedback.json
  runs/
    .gitkeep
```

## Installation

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

On macOS/Linux, activate with:

```bash
source .venv/bin/activate
```

## Run FastAPI Backend

```bash
uvicorn src.main_api:app --reload --host 127.0.0.1 --port 8000
```

Then open:

- Health check: <http://127.0.0.1:8000/health>
- API docs: <http://127.0.0.1:8000/docs>

Main endpoints:

- `GET /health`
- `POST /api/run`
- `GET /api/runs/{run_id}`
- `GET /api/runs/{run_id}/report`
- `POST /api/runs/{run_id}/human_feedback`

## Run Streamlit Frontend

```bash
streamlit run app_streamlit.py
```

The frontend lets you enter the research goal, constraints, max iterations, and optional human feedback. It displays each iteration plan, result table, AI analysis, critic feedback, efficiency curve, and final report downloads.

## Configure Qwen API

Copy `.env.example` to `.env` and fill in your own values:

```env
DASHSCOPE_API_KEY=your_key_here
LLM_PROVIDER=qwen
LLM_MODEL=qwen-plus
LLM_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

Do not hard-code keys in source code. If `LLM_PROVIDER` is not set to `qwen`, the project uses `MockLLMProvider`.

## Run Examples

```bash
python run_examples.py
```

This runs:

- `examples/case_efficiency_first.json`
- `examples/case_low_energy.json`
- `examples/case_human_feedback.json`

Each run writes artifacts under `runs/{run_id}/`, including:

- `config.json`
- `problem_analysis.json`
- `iteration_1_plan.json`
- `iteration_1_results.csv`
- `iteration_1_analysis.json`
- `iteration_1_feedback.json`
- `final_report.md`
- `final_report.json`

## How This Matches the Competition Direction

The project is built around "scientific experiment task planning and feedback iteration":

- `ProblemAnalystAgent` structures the goal, variables, constraints, and priorities.
- `ExperimentPlannerAgent` proposes concrete experiment parameter combinations.
- `SimulationExecutor` is represented by `SoftSwimmerSimulator`.
- `DataAnalystAgent` ranks measured candidates and identifies failures.
- `CriticAgent` translates results into next-round planning guidance.
- `ReportWriterAgent` generates the final scientific-style report.

Most importantly, later plans are not random. They react to measured results:

- If energy is too high, lower frequency or amplitude.
- If stability is too low, lower amplitude or increase stiffness.
- If speed is too low, increase frequency or amplitude.
- If the target improves, continue local search around the best candidate.

## Virtual Simulator Limits

The current simulator is a lightweight virtual experiment backend. It is useful for demos, debugging workflow design, and showing the closed-loop logic.

It is not a high-fidelity physical model:

- Equations are qualitative and hand-designed.
- Noise is simple seeded random noise.
- Vortex loss is a surrogate metric.
- No mesh, boundary condition, turbulence, or fluid-structure coupling solver is included.

## Replacing With FreeFlow / CFD Adapter

To connect a real simulator, replace or wrap `src/simulator/soft_swimmer_simulator.py` with an adapter that:

1. Receives `ExperimentParams`.
2. Writes solver input files or calls a FreeFlow/CFD API.
3. Runs the simulation job.
4. Parses physical outputs into:
   - `mean_speed`
   - `energy_cost`
   - `efficiency`
   - `stability_score`
   - `vortex_loss`
   - `constraint_violation`
5. Returns the same `SimulationResult` schema.

The workflow, API, Streamlit UI, and report writer can remain mostly unchanged if the adapter preserves the schema.

## Report References

The generated report contains placeholder references only:

- `[To be filled manually] Literature on soft robotic swimmers and flow-field optimization.`
- `[To be filled manually] Literature on AI Scientist and multi-agent scientific discovery.`

You must manually replace these placeholders with real verified literature before submitting a formal report or paper.
